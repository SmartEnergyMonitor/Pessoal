/******************************************************************************************************************/
/* Cubos                                                                                                          */
/******************************************************************************************************************/
/* Instituto Politecnico de Portalegre                                                                            */
/* Engenharia Informatica                                                                                         */
/* Computacao Grafica - Trabalho 2                                                                               */
/*                                                                                                                */
/* Elias Pinheiro n 17527                                                                                         */
/*                                                                                                                */
/******************************************************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <glut.h>
#include <stdbool.h>



#define CELL_SIZE 1.2
#define TAB_SIZE 13




//Arrays do Cubo
GLfloat vertices[][3] = { {-1.0,-1.0,-1.0},{1.0,-1.0,-1.0},
{1.0,1.0,-1.0}, {-1.0,1.0,-1.0}, {-1.0,-1.0,1.0},
{1.0,-1.0,1.0}, {1.0,1.0,1.0}, {-1.0,1.0,1.0} };

GLfloat normals[][3] = { {-1.0,-1.0,-1.0},{1.0,-1.0,-1.0},
{1.0,1.0,-1.0}, {-1.0,1.0,-1.0}, {-1.0,-1.0,1.0},
{1.0,-1.0,1.0}, {1.0,1.0,1.0}, {-1.0,1.0,1.0} };



//Arrays da Piramide
GLfloat verticesTri[][3] = { { -1.0,-1.0,-1.0 },  //0
{ 1.0,-1.0,-1.0 },   //1
{ 1.0,1.0,-1.0 },    //2
{ -1.0,1.0,-1.0 },   //3
{ 0.0,0.0,1.0 } };    //4

GLfloat normalsTri[][3] = { { -1.0,-1.0,-1.0 },{ 1.0,-1.0,-1.0 },
{ 1.0,1.0,-1.0 },{ -1.0,1.0,-1.0 },{ 0.0,0.0,1.0 } };



//estrutura de dados - cubo
typedef struct cubo * Cubo;
struct cubo {
	float x, y, z;
	float scale;
	float xRot, yRot;
	float xRoti, yRoti;

	// Matriz de rota��o que define a posi��o actual do cubo
	GLfloat m[16];

	float r, g, b;
};


//estrutura de dados - piramide
typedef struct piramide * Piramide;
struct piramide {
	float x, y, z;
	float scale;
	float xRot, yRot;   // Rota��o necess�ria em x e em y em graus multiplos de 90
	float xRoti, yRoti; // Rota��o actual em x e em y at� atingir xRot e yRot, respectivamente

						// Matriz de rota��o que define a posi��o actual do cubo
	GLfloat m[16];

	float r, g, b;
};


Cubo *aCubos;			// array de cubos
int nCubos = 4;			// array dos cubos controlados pelo utilizador

Piramide *aPiramidesObst;		//array de obstaculos
Cubo *cuboObsMov;				//array de cubos moveis



bool camPanMode = false;		//estado de movimento de camera
bool camZoomMode = false;		//estado de zoom de camera


int timeUpdate = 20;       // intervalo de tempo (ms) para o update
float velRot = 200.0;      // velocidade de rota��o dos cubos em graus/s
float angRotMax = 90;

float distCamara = 9;		//distacia da camera
float dDistCamara = 0.8;    //desta da distancia de camera

//posi��o incial da camera
float alfaLongitude = 0;
float alfaLatitude = 20;

float xRato, yRato;   // guarda a �ltima posi��o do rato (para calcular o deslocamento na Lat. e Long.)
float angRato = 0.25;  // precis�o do rato: n�mero de angulos por pixel.


//Poligonos para o cubo
void polygon(int a, int b, int c, int d)
{
	glBegin(GL_POLYGON);
	//glColor3fv(colors[a]);
	glNormal3fv(normals[a]);
	glVertex3fv(vertices[a]);
	//glColor3fv(colors[b]);
	glNormal3fv(normals[b]);
	glVertex3fv(vertices[b]);
	//glColor3fv(colors[c]);
	glNormal3fv(normals[c]);
	glVertex3fv(vertices[c]);
	//glColor3fv(colors[d]);
	glNormal3fv(normals[d]);
	glVertex3fv(vertices[d]);
	glEnd();
}


//Linewire para o cubo
void lineloop(int a, int b, int c, int d)
{

	/* draw a lineloop via list of vertices */
	glColor3f(1.0, 1.0, 1.0);
	glBegin(GL_LINE_LOOP);
	glVertex3fv(vertices[a]);
	glVertex3fv(vertices[b]);
	glVertex3fv(vertices[c]);
	glVertex3fv(vertices[d]);
	glEnd();
}


//Compoe o cubo
void colorcube(void)
{
	polygon(0, 3, 2, 1);
	polygon(2, 3, 7, 6);
	polygon(0, 4, 7, 3);
	polygon(1, 2, 6, 5);
	polygon(4, 5, 6, 7);
	polygon(0, 1, 5, 4);

	lineloop(0, 3, 2, 1);
	lineloop(2, 3, 7, 6);
	lineloop(0, 4, 7, 3);
	lineloop(1, 2, 6, 5);
	lineloop(4, 5, 6, 7);
	lineloop(0, 1, 5, 4);
}



//poligonos para as piramides
void polygonTri(int a, int b, int c)
{
	glBegin(GL_POLYGON);

	glNormal3fv(normalsTri[a]);
	glVertex3fv(verticesTri[a]);

	glNormal3fv(normalsTri[b]);
	glVertex3fv(verticesTri[b]);

	glNormal3fv(normalsTri[c]);
	glVertex3fv(verticesTri[c]);
	glEnd();
}


//linewire para a piramide
void lineloopTri(int a, int b, int c)
{
	glColor3f(1.0, 1.0, 1.0);
	glBegin(GL_LINE_LOOP);
	glVertex3fv(verticesTri[a]);
	glVertex3fv(verticesTri[b]);
	glVertex3fv(verticesTri[c]);
	glEnd();
}



//compoe a piramide
void pyramid(void)
{
	polygonTri(1, 2, 4);
	polygonTri(2, 3, 4);
	polygonTri(3, 0, 4);
	polygonTri(0, 1, 3);
	polygonTri(3, 1, 2);
	polygonTri(3, 1, 4);
	


	lineloopTri(1, 2, 4);
	lineloopTri(2, 3, 4);
	lineloopTri(3, 0, 4);
	lineloopTri(3, 1, 4);
	

}

//cria cubo
Cubo criaCubo(float x, float y, float z, float scale)
{
	Cubo c = (Cubo)malloc(sizeof(*c));
	c->x = x;
	c->y = y;
	c->z = z;
	c->scale = scale;
	c->xRot = c->yRot = c->xRoti = c->yRoti = 0.0;

	c->r = 0;
	c->g = 1;
	c->b = 0;

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glGetFloatv(GL_MODELVIEW_MATRIX, c->m);
	glPopMatrix();

	return c;
}

//cria piramide
Piramide criaPiramide(float x, float y, float z, float scale)
{
	Piramide p = (Piramide)malloc(sizeof(*p));
	p->x = x;
	p->y = y;
	p->z = z;
	p->scale = scale;
	p->xRot = p->yRot = p->xRoti = p->yRoti = 0.0;

	p->r = 0;
	p->g = 1;
	p->b = 0;

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glGetFloatv(GL_MODELVIEW_MATRIX, p->m);
	glPopMatrix();

	return p;
}


//desenha o tabuleiro
void desenhaTabuleiro()
{
	int i, j;


	glPushMatrix();

	glScalef(0.3, 0.3, 0.3);
	if (TAB_SIZE % 2 != 0) {
		glTranslatef(-TAB_SIZE + 1, 0, -TAB_SIZE + 1);
	}
	else
	{
		glTranslatef(-TAB_SIZE, 0, -TAB_SIZE);
	}

	for (i = 0; i < TAB_SIZE; i++)
		for (j = 0; j < TAB_SIZE; j++) {
			glPushMatrix();
			glTranslatef(j*2.0, -2.0, i*2.0);
			glScalef(0.95, 0.95, 0.95);
			glColor3f(0.0, 0.0, 1.0);
			colorcube();
			glPopMatrix();
		}

	glPopMatrix();
}



void actualizaRotCubo(Cubo c, GLfloat ang, GLfloat x, GLfloat y, GLfloat z)
{
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glRotatef(ang, x, y, z);
	glMultMatrixf(c->m);
	glGetFloatv(GL_MODELVIEW_MATRIX, c->m);
	glPopMatrix();
}

void rodaCuboCima(Cubo c)
{
	if (c->yRot == c->yRoti)     // n�o est� a rodar em Y
		c->xRot += -angRotMax;
}

void rodaCuboBaixo(Cubo c)
{
	if (c->yRot == c->yRoti)     // n�o est� a rodar em Y
		c->xRot += angRotMax;
}

void rodaCuboEsq(Cubo c)
{
	if (c->xRot == c->xRoti)     // n�o est� a rodar em X
		c->yRot += -angRotMax;
}

void rodaCuboDir(Cubo c)
{
	if (c->xRot == c->xRoti)     // n�o est� a rodar em X
		c->yRot += angRotMax;
}

void rodaPiramide(Piramide p)
{
	if (p->yRot == p->yRoti)
		p->xRot += angRotMax;
}


void desenhaCubo(Cubo c)
{

	if (c == NULL) return;

	glPushMatrix();

	glTranslatef(c->x, c->y, c->z);
	glScalef(c->scale, c->scale, c->scale);

	glRotatef(c->xRoti, 1, 0, 0);
	glRotatef(c->yRoti*-1, 0, 0, 1);

	glMultMatrixf(c->m);

	glColor3f(c->r, c->g, c->b);
	colorcube();

	glPopMatrix();
}


void desenhaPiramide(Piramide p)
{

	if (p == NULL) return;

	glPushMatrix();

	glTranslatef(p->x, p->y, p->z);
	glScalef(p->scale, p->scale, p->scale);

	glRotatef(p->xRoti, 0, 1, 0);
	glRotatef(p->yRoti*-1, 0, 0, 1);

	glMultMatrixf(p->m);

	glColor3f(p->r, p->g, p->b);
	pyramid();

	glPopMatrix();
}



void updateCubo(Cubo c, int t)
{	
	float angMov = velRot*(t / 1000.0);
	//printf("%f\n", angMov);
	if (c->xRot != 0 || c->xRoti != 0) {
		if (c->xRot > c->xRoti) { c->xRoti += angMov; c->z += (0.5*CELL_SIZE) / (angRotMax / angMov)+0.0007; }
		if (c->xRot < c->xRoti) { c->xRoti -= angMov; c->z -= (0.5*CELL_SIZE) / (angRotMax / angMov)+0.0007; }
		if (fabs(c->xRot - c->xRoti) < angMov) {
			actualizaRotCubo(c, c->xRot, 1, 0, 0);
			c->xRot = c->xRoti = 0.0;
		}
	}

	if (c->yRot != 0 || c->yRoti != 0) {
		if (c->yRot > c->yRoti) { c->yRoti += angMov; c->x += (0.5*CELL_SIZE) / (angRotMax / angMov)+0.0007; }
		if (c->yRot < c->yRoti) { c->yRoti -= angMov; c->x -= (0.5*CELL_SIZE) / (angRotMax / angMov)+0.0007; }
		if (fabs(c->yRot - c->yRoti) < angMov) {
			actualizaRotCubo(c, c->yRot, 0, 1, 0);
			c->yRot = c->yRoti = 0.0;
		}
	}
}

void updatePiramide(Piramide p, int t)
{
	float angMov = velRot*(t / 1000.0);
	if (p->xRot != 0 || p->xRoti != 0) {
		if (p->xRot > p->xRoti) { p->xRoti += angMov;}
		if (p->xRot < p->xRoti) { p->xRoti -= angMov;}
		if (fabs(p->xRot - p->xRoti) < angMov) {
			actualizaRotCubo((Cubo)p, p->xRot, 1, 0, 0);
			p->xRot = p->xRoti = 0.0;
		}
	}
}



void display(void)
{
	int i;
	float x, y, z;

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glShadeModel(GL_FLAT);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	x = distCamara * sin(alfaLongitude*3.14 / 180) * cos(alfaLatitude*3.14 / 180);
	z = distCamara * cos(alfaLongitude*3.14 / 180) * cos(alfaLatitude*3.14 / 180);
	y = distCamara * sin(alfaLatitude*3.14 / 180);
	gluLookAt(x, y, z, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

	desenhaTabuleiro();

	for (int i = 0; i < 2; i++)
	{
		desenhaCubo(cuboObsMov[i]);
	}
	for (i = 0; i < 4; i++)
	{
		desenhaPiramide(aPiramidesObst[i]);
	}


	for (i = 0; i < nCubos; i++)
		desenhaCubo(aCubos[i]);

	glFlush();

	glutSwapBuffers();
}

void myReshape(int w, int h)
{
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	if (w <= h)
		glFrustum(-2.0, 2.0, -2.0 * (GLfloat)h / (GLfloat)w,
			2.0 * (GLfloat)h / (GLfloat)w, 3.0, 100.0);
	else
		glFrustum(-2.0 * (GLfloat)w / (GLfloat)h,
			2.0 * (GLfloat)w / (GLfloat)h, -2.0, 2.0, 3.0, 100.0);
	glMatrixMode(GL_MODELVIEW);
}

bool inCubo(Cubo a, Cubo b)
{
	if ((a->x >= b->x - 0.4 && a->x <= b->x + 0.4) && (a->z >= b->z - 0.4 && a->z <= b->z + 0.4))
	{
		return true;
	}
	else return false;
}


void moveObsMov(Cubo x, Cubo y)
{
	static int dir = 1;

	x->z += 0.1*CELL_SIZE*dir;
	y->z -= 0.1*CELL_SIZE*dir;

	for (int i = 0; i < nCubos; i++)
	{
		if (inCubo(x, aCubos[i]))
		{
			aCubos[i]->z += 0.1*CELL_SIZE*dir;
		}

		if (inCubo(y, aCubos[i]))
		{
			aCubos[i]->z -= 0.1*CELL_SIZE*dir;
		}
	}


	if (x->z > 2.5*CELL_SIZE || x->z < -2.5*CELL_SIZE)
	{
		dir *= -1;
	}
}


void update(int v)
// timer callback
{
	int i;

	for (i = 0; i < nCubos; i++)
		updateCubo(aCubos[i], v);


	
		moveObsMov(cuboObsMov[0], cuboObsMov[1]);

	for (int i = 0; i < 4; i++)
	{
		rodaPiramide(aPiramidesObst[i]);
		updatePiramide(aPiramidesObst[i],v);
	}

	glutPostRedisplay();
	glutTimerFunc(v, update, v);
}


void teclas(unsigned char key, int x, int y)
{
	switch (key) {
	case 'q':
	case 'Q':
		exit(0);
		break;
	case 'a':
		if(distCamara > 8.4) {
			distCamara -= dDistCamara;
			printf("%f\n", distCamara);
		}
		break;
	case 'b':
		if (distCamara < 16.0)
		distCamara += dDistCamara;
		printf("%f\n", distCamara);
		break;
	}
}




void teclasEspeciais(int key, int x, int y)
{
	switch (key) {
	case GLUT_KEY_UP:
	{
		for (int i = 0; i < nCubos; i++)
		{
			aCubos[i]->z -= 0.5*CELL_SIZE;
			for (int j = 0; j < 4; j++) {
				if (inCubo(aCubos[i], (Cubo)aPiramidesObst[j]) || (aCubos[i]->z <= (float)((TAB_SIZE/2)+1)*(0.5*CELL_SIZE*-1)+0.4))
				{
					aCubos[i]->z += 0.5*CELL_SIZE;
					return;
				}
			}
			aCubos[i]->z += 0.5*CELL_SIZE;
		}

		for (int i = 0; i < nCubos; i++)
		{
			rodaCuboCima(aCubos[i]);
		}
		break;
	}
	case GLUT_KEY_DOWN:
	{
		for (int i = 0; i < nCubos; i++)	
		{
			aCubos[i]->z += 0.5*CELL_SIZE;
			for (int j = 0; j < 4; j++) {
				if (inCubo(aCubos[i], (Cubo)aPiramidesObst[j]) || (aCubos[i]->z >= (float)((TAB_SIZE / 2) + 1)*(0.5*CELL_SIZE)-0.4))
				{
					aCubos[i]->z -= 0.5*CELL_SIZE;
					return;
				}
			}
			aCubos[i]->z -= 0.5*CELL_SIZE;
		}

		for (int i = 0; i < nCubos; i++)
		{
			rodaCuboBaixo(aCubos[i]);
		}
		break;
	}
	case GLUT_KEY_LEFT:
	{
		for (int i = nCubos-1; i >=0; i--)
		{
			aCubos[i]->x -= 0.5*CELL_SIZE;
			for (int j = 0; j < 4; j++) {
				if (inCubo(aCubos[i], (Cubo)aPiramidesObst[j]) || (aCubos[i]->x <= (float)((TAB_SIZE / 2) + 1)*0.5*CELL_SIZE*-1))
				{
					aCubos[i]->x += 0.5*CELL_SIZE;
					return;
				}
			}
			aCubos[i]->x += 0.5*CELL_SIZE;
		}

		for (int i = 0; i < nCubos; i++)
		{
			rodaCuboEsq(aCubos[i]);
		}
		break;
	}
	case GLUT_KEY_RIGHT:
	{
		for (int i = nCubos-1; i>=0 ; i--)
		{
			aCubos[i]->x += 0.5*CELL_SIZE;
			for (int j = 0; j < 4; j++) {
				//printf("%d", inCubo(aCubos[i], (Cubo)aPiramidesObst[j]));
				if (inCubo(aCubos[i], (Cubo)aPiramidesObst[j]) || (aCubos[i]->x >= (float)((TAB_SIZE / 2) + 1)*0.5*CELL_SIZE))
				{
					aCubos[i]->x -= 0.5*CELL_SIZE;
					return;
				}
			}
			aCubos[i]->x -= 0.5*CELL_SIZE;
		}

		for (int i = 0; i < nCubos; i++)
		{
			rodaCuboDir(aCubos[i]);
		}
		break;
	}
	}
	glutPostRedisplay();
}


// mouse callback
void rato(GLint button, GLint state, GLint x, GLint y)
{
	xRato = x;
	yRato = y;

	if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		camPanMode = true;
	}

	if (button == GLUT_RIGHT_BUTTON && state == GLUT_UP)
	{
		camPanMode = false;
	}

	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		camZoomMode = true;
	}


	if (button == GLUT_LEFT_BUTTON && state == GLUT_UP)
	{
		camZoomMode = false;
	}
}


void moveRatoPress(int x, int y)
{

	if (camPanMode == true)
	{
		alfaLongitude += (x - xRato) * angRato;

		if (alfaLatitude >= 9 && alfaLatitude < 51)
		{
			alfaLatitude -= (y - yRato) * angRato;
		}
		else if (alfaLatitude < 9) alfaLatitude = 9;
		else if (alfaLatitude > 50) alfaLatitude = 50;


		xRato = x;
		yRato = y;

		if (alfaLongitude >= 360) alfaLongitude -= 360;
		if (alfaLongitude < 0) alfaLongitude += 360;
		if (alfaLatitude >= 360) alfaLatitude -= 360;
		if (alfaLatitude < 0) alfaLatitude += 360;

		printf("R(Lon,Lat)=(%6.2f,%6.2f)\n", alfaLongitude, alfaLatitude);

		glutPostRedisplay();
	}

	if (camZoomMode == true)
	{
		if (yRato < y)
		{
			if (distCamara < 70.0)
				distCamara += dDistCamara;
		}
		else
		{
			if (distCamara > 8.4)
				distCamara -= dDistCamara;
		}
		xRato = x;
		yRato = y;
	}
}



void myInit()
{

	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);  //Corre��o de perspectiva. Vertices mais definidos


	int i;
	float entreCubos = CELL_SIZE;
	float tamanhoCubo = 0.3;
	float inicio = -(nCubos / 2) * entreCubos;



	if (nCubos % 2 == 0) // numero par de cubos
		inicio += (entreCubos / 2);


	aCubos = (Cubo*)malloc(sizeof(Cubo)*nCubos);
	for (i = 0; i < nCubos; i++) {
		aCubos[i] = criaCubo(0.0 + i*entreCubos, 0.0, 0.0, tamanhoCubo);
		aCubos[i]->r = ((float)rand()) / RAND_MAX;
		aCubos[i]->g = ((float)rand()) / RAND_MAX;
		aCubos[i]->b = ((float)rand()) / RAND_MAX;

	}

	aPiramidesObst = (Piramide*)malloc(sizeof(Piramide) * 4);
	aPiramidesObst[0] = criaPiramide(-2.0*entreCubos, 0.0, -2.0*entreCubos, tamanhoCubo);
	aPiramidesObst[0]->r = 1.0;
	aPiramidesObst[0]->g = 0.0;
	aPiramidesObst[0]->b = 0.0;
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glRotatef(-90, 1, 0, 0);
	glMultMatrixf(aPiramidesObst[0]->m);
	glGetFloatv(GL_MODELVIEW_MATRIX, aPiramidesObst[0]->m);
	glPopMatrix();

	aPiramidesObst[1] = criaPiramide(-2.0*entreCubos, 0.0, 2.0*entreCubos, tamanhoCubo);
	aPiramidesObst[1]->r = 1.0;
	aPiramidesObst[1]->g = 0.0;
	aPiramidesObst[1]->b = 0.0;
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glRotatef(-90, 1, 0, 0);
	glMultMatrixf(aPiramidesObst[1]->m);
	glGetFloatv(GL_MODELVIEW_MATRIX, aPiramidesObst[1]->m);
	glPopMatrix();

	aPiramidesObst[2] = criaPiramide(2.0*entreCubos, 0.0, -2.0*entreCubos, tamanhoCubo);
	aPiramidesObst[2]->r = 1.0;
	aPiramidesObst[2]->g = 0.0;
	aPiramidesObst[2]->b = 0.0;
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glRotatef(-90, 1, 0, 0);
	glMultMatrixf(aPiramidesObst[2]->m);
	glGetFloatv(GL_MODELVIEW_MATRIX, aPiramidesObst[2]->m);
	glPopMatrix();

	aPiramidesObst[3] = criaPiramide(2.0*entreCubos, 0.0, 2.0*entreCubos, tamanhoCubo);
	aPiramidesObst[3]->r = 1.0;
	aPiramidesObst[3]->g = 0.0;
	aPiramidesObst[3]->b = 0.0;
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glRotatef(-90, 1, 0, 0);
	glMultMatrixf(aPiramidesObst[3]->m);
	glGetFloatv(GL_MODELVIEW_MATRIX, aPiramidesObst[3]->m);
	glPopMatrix();

	cuboObsMov = (Cubo*)malloc(sizeof(Cubo) * 2);
	cuboObsMov[0] = criaCubo(-2.5*entreCubos, 0.0, -2.5*entreCubos, tamanhoCubo);
	cuboObsMov[0]->r = 1;
	cuboObsMov[0]->g = 1;
	cuboObsMov[0]->b = 0;

	cuboObsMov[1] = criaCubo(2.5*entreCubos, 0.0, 2.5*entreCubos, tamanhoCubo);
	cuboObsMov[1]->r = 1;
	cuboObsMov[1]->g = 1;
	cuboObsMov[1]->b = 0;
}

void main(int argc, char **argv)
{
	glutInit(&argc, argv);

	/* need both double buffering and z buffer */

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(500, 500);
	glutCreateWindow("Cubos");
	myInit();
	glutReshapeFunc(myReshape);
	glutDisplayFunc(display);
	glutKeyboardFunc(teclas);
	glutSpecialFunc(teclasEspeciais);
	glutMouseFunc(rato);
	glutMotionFunc(moveRatoPress);
	glEnable(GL_DEPTH_TEST); /* Enable hidden--surface--removal */
	glutTimerFunc(timeUpdate, update, timeUpdate);
	glutMainLoop();
}
